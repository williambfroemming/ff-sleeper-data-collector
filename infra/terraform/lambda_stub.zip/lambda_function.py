import json, datetime

def handler(event, context):
    return {
        "status": "ok",
        "ts": datetime.datetime.utcnow().isoformat(),
        "note": "replace with Sleeper ingest later"
    }
